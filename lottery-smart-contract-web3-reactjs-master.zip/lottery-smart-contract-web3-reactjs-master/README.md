# Lottery Smart Contract

A simple lottery smart contract using Web3 and React Js

You need a contract address and contract abi to run this.

Contract deployment into blockchain using solidity, web3 and mocha can be found [HERE](https://github.com/zelva3/lottery-smartcontract-solidity-web3)
